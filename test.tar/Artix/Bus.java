package Artix;

public class Bus extends Transport {
    Bus() {
        Name = "Автобус";
        NumberOfWheels = 4;
        MaxSpeed = 100;
        String Gearbox = "Механическая";
        int NumberOfFloors = 2;

        System.out.println("Название транспорта: " + Name);
        System.out.println("Количество колес: " + NumberOfWheels);
        System.out.println("Максимальная скорость: " + MaxSpeed);
        System.out.println("Коробка передач " + Gearbox);
        System.out.println("Количество этажей: " + NumberOfFloors);
        System.out.println();

    }
};
