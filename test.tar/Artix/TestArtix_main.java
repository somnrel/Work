package Artix;

import java.util.Scanner;

public class TestArtix_main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in); // Объявляем Scanner
        System.out.println("Введите количество единиц транспорта, которое нужно создать: ");
        int size = input.nextInt(); // Читаем с клавиатуры размер массива и записываем в size
        int[] arrayTypes = new int[size]; // Создаём массив int размером в size
        System.out.println("Допустимые значения типов транспорта: 0 - мотоцикл 1 - самокат 2 - автомобиль 3 - автобус");

        System.out.println("Введите значение типов транспорта через пробел:");
// Заполним массив значениями типов транспорта
        for (int i = size; i > 0; i--) {
            arrayTypes[i - 1] = input.nextInt(); // Заполняем массив элементами, введёнными с клавиатуры
        }
        Transport transport = new Artix.Transport(arrayTypes);
    }
}
