package Artix;

public class Car extends Transport {

    public Car() {
        Name = "Автомобиль";
        NumberOfWheels = 4;
        MaxSpeed = 150;
        String EngineType = "Электродвигатель";

        System.out.println("Название транспорта: " + Name);
        System.out.println("Количество колес: " + NumberOfWheels);
        System.out.println("Максимальная скорость: " + MaxSpeed);
        System.out.println("Тип двигателя: " + EngineType);
    }
};
