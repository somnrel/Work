package Artix;

public class Scooter extends Transport {

    public Scooter() {
        Name = "Самокат";
        NumberOfWheels = 2;
        MaxSpeed = 25;
        double HandlebarHeight = 106.0;
        String TypeOfScooter = "Городской самокат";

        System.out.println("Название транспорта: " + Name);
        System.out.println("Количество колес: " + NumberOfWheels);
        System.out.println("Максимальная скорость: " + MaxSpeed);
        System.out.println("Высота руля: " + HandlebarHeight);
        System.out.println("Тип самоката: " + TypeOfScooter);
        System.out.println();
    }
};
