package Artix;

public class ClassFactory {
    public Transport CreateTransport(int type) {
        Transport transport = null;

        switch (type) {
            case 0:
                transport = new Motorbike();
                break;
            case 1:
                transport = new Scooter();
                break;
            case 2:
                transport = new Car();
                break;
            case 3:
                transport = new Bus();
                break;
            default:
                System.out.println("НЕИЗВЕСТНЫЙ ТИП ТРАНСПОРТА");
                System.out.println();
        }
        return transport;


    }
};