package Artix;

public class Transport {
    protected String Name;
    protected int NumberOfWheels;
    protected int MaxSpeed;

    // Конструктор для создания классов транспорта, с любым количеством параметров. Доступные параметры:
    //   0 - Мотоцикл
    //   1 - Самокат
    //   2 - Автомобиль
    //   3 - Автобус
    //   При вводе недопустимого значения параметра отобразится сообщение: "НЕИЗВЕСТНЫЙ ТИП ТРАНСПОРТА".
    public Transport(int[] i) {

        for (int len = i.length; len > 0; len--) {
            ClassFactory factory = new ClassFactory();
            Transport Transport_1 = factory.CreateTransport(i[len - 1]);
        }
    }

    public Transport() {

    }
};
