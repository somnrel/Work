package Artix;

class Motorbike extends Transport {
    Motorbike() {
        Name = "Мотоцикл";
        NumberOfWheels = 2;
        MaxSpeed = 200;
        String Footrests = "Центральная подножка";

        System.out.println("Название транспорта: " + Name);
        System.out.println("Количество колес: " + NumberOfWheels);
        System.out.println("Максимальная скорость: " + MaxSpeed);
        System.out.println("Подножка мотоцикла: " + Footrests);
        System.out.println();
    }
};
